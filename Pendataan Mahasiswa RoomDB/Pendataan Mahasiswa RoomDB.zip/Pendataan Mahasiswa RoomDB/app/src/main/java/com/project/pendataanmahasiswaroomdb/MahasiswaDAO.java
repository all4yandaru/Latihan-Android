package com.project.pendataanmahasiswaroomdb;
// TODO 3: buat interface DAO (Data Access Database) tambahin annotation @Dao

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;

@Dao
public interface MahasiswaDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE) // kalo data udah ada, nanti bakal di replace
    long insertMahasiswa(Mahasiswa mahasiswa);
}
