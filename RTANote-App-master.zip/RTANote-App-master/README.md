# RTANote-App

This is my android app project
